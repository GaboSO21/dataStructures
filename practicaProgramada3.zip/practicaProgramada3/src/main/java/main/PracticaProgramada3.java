/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package main;

import Menu.Menu;

/**
 *
 * @author 
 * Gabriel Sanchez Olveira
 * Andres Ospina Perilla
 * Johan Navarro Saenz
 * Jose Ignacio Jimenez Songg
 */
public class PracticaProgramada3 {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.mostrar();
    }
}

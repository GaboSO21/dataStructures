package Menu;

import javax.swing.JOptionPane;

import Arbol.Arbol;

public class Menu {

    public Arbol arbol = new Arbol();

    public void mostrar() {

        int op = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Menu Principal\n" +
                        "1. Agregar elemento\n" +
                        "2. Mostrar elemento (normal)\n" +
                        "3. Contar repetidos\n" +
                        "4. Imprimir hermanos izquierdos de nodo\n" +
                        "9. Salir\n",
                "Menu principal", JOptionPane.QUESTION_MESSAGE));
        switch (op) {
            case 1:
                arbol.crearRaiz();
                mostrar();
            case 2:
                System.out.println(" ");
                arbol.mostrarRaiz();
                mostrar();
            case 3:
                System.out.println("Se repiten " + arbol.contarRepetidos() + " elementos.");
                mostrar();
            case 4:
                System.out.println(" ");
                arbol.buscarIzq(Integer.parseInt(
                        JOptionPane.showInputDialog(null, "Ingrese nodo para imprimir sus hermanos izquierdos: ", "Hermanos", 1)));
                mostrar();
            case 9:
                System.exit(0);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opcion invalida!", "Error", JOptionPane.ERROR_MESSAGE);
                mostrar();
        }

    }

}
